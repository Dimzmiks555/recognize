# 🌐 Python Face Analyzer
## Know more ways? Create a pull request!
---
More interesting projects: - https://netstalkers.com/private

### 🎥 [PYTHON:TODAY](https://youtu.be/gvYGIhuiJQI)
### 🔥 [Telegram](https://t.me/python2day)
---
```
$ pip install deepface
```
---

[Code](https://github.com/pythontoday/face_analyzer)
